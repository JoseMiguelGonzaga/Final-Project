
public class Customer extends OrderLine
{
	private int customerid;
	private String customerlname;
	private String customeraddress;
	private String customercontactno;
	private int customertin;

	// Getters for Customer class
	public int getCustomerID()
	{
		return this.customerid;
	}
	
	public String getCustomerlname()
	{
		return this.customerlname;
	}
	
	public String getCustomeraddress()
	{
		return this.customeraddress;
	}
	
	public String getCustomercontactno()
	{
		return this.customercontactno;
	}
	
	public int getCustomertin()
	{
		return this.customertin;
	}
	
	// Setters for Customer class
	public int setCustomerID(int customerid)
	{
		return this.customerid = customerid;
		
	}
	
	public String setCustomerlname(String customername)
	{
		return this.customerlname = customername;
	}
	
	public String setCustomeraddress(String customeraddress)
	{
		return this.customeraddress = customeraddress;
	}
	
	public String setCustomercontactno(String customercontactno)
	{
		return this.customercontactno = customercontactno;
	}
	
	public int setCustomertin(int customertin)
	{
		return this.customertin = customertin;
	}
}
