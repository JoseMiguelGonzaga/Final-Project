import java.sql.*;
import java.util.Scanner;

/**
 * The purpose of this class is to manage the inventory database
 * for the inventory custodian, the inventory custodian
 * can add, modify, and delete item info from the database.
 */
public class Invsort
{
    private Scanner in;

    // Constructor for scanner in
    public Invsort(Scanner in)
    {
        this.in = in;
    }

    /**
     * This method lets the inventory custodian
     * add item info onto the database
     */
    public void addItem()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/breweryinventory","root","josegonzaga" );
            PreparedStatement insert = con.prepareStatement("INSERT INTO inventory(ItemID,ItemName,ItemType,UnitCost,ItemCost,ItemQty) VALUES(?,?,?,?,?,?)");
            con.createStatement();
            Inventory inv = new Inventory();

            System.out.println("Enter item id: ");
            inv.setItemID(in.nextInt());
            in.nextLine();

            System.out.println("Enter item name: ");
            inv.setItemname(in.nextLine());

            System.out.println("Enter item type (Alcohol or Softdrink): ");
            inv.setItemtype(in.nextLine());

            System.out.println("Enter the Unit cost of the product: ");
            inv.setUnitcost(in.nextInt());

            System.out.println("Enter the Item cost of the product: ");
            inv.setItemcost(in.nextInt());
            in.nextLine();

            System.out.println("Enter the quantity of the product: ");
            inv.setItemquantity(in.nextInt());

            insert.setInt(1,inv.getItemID());
            insert.setString(2,inv.getItemname());
            insert.setString(3,inv.getItemtype());
            insert.setInt(4,inv.getUnitcost());
            insert.setInt(5,inv.getItemcost());
            insert.setInt(6,inv.getItemquantity());

            insert.executeUpdate();
            con.close();
            System.out.println("Item is added into the Inventory!");
            System.out.println();
        }
        
        catch(Exception e)
        {
            System.out.println("Error Occured, please try again.");
        }
    }

    /*
     * This method allows the inventory custodian to 
     * modifies the Item data within the database table of inventory
     * The user can choose between the ff:
     * 1. the entire row by inputting the item id in the method.
     * 2. Choosing the specific column/data type of the table to be changed.
     */
    public void modifyItem()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/breweryinventory","root","josegonzaga" );
            Inventory inv = new Inventory();
            System.out.println("Modifying Options");
            System.out.println("1. All row");
            System.out.println("2. Specified column");
            System.out.print("Choice: ");
            int chosen = in.nextInt();
            System.out.println();

            if (chosen == 1)
            {
                String sql = "UPDATE inventory SET ItemName = ?, ItemType = ?, UnitCost = ?, ItemCost = ?, ItemQty = ? WHERE ItemID = ? ";
                PreparedStatement modifyr = con.prepareStatement(sql);
                con.createStatement();
                
                in.nextLine();
                System.out.print("Input new ItemName: ");
                modifyr.setString(1,in.nextLine());
                System.out.print("Input new ItemType: ");
                modifyr.setString(2,in.nextLine());
                System.out.print("Input new UnitCost: ");
                modifyr.setInt(3,in.nextInt());
                System.out.print("Input new ItemCost: ");
                modifyr.setInt(4,in.nextInt());
                System.out.print("Input new ItemQty: ");
                modifyr.setInt(5, in.nextInt());
                System.out.print("Input the itemID that needs change: ");
                modifyr.setInt(6, in.nextInt());
                modifyr.executeUpdate();
                con.close();
            }
            
            if(chosen == 2)
            {
                System.out.println("Which of these do you want to change?");
                System.out.println("1. ItemName");
                System.out.println("2. ItemType");
                System.out.println("3. UnitCost");
                System.out.println("4. ItemCost");
                System.out.println("5. ItemQty");
                System.out.print("Choice: ");
                int choosen = in.nextInt();
                in.nextLine();
                
                if (choosen == 1)
                {
                    String sql = "UPDATE inventory SET ItemName = ? WHERE ItemID = ?";
                    PreparedStatement modifys = con.prepareStatement(sql);
                    con.createStatement();
                    System.out.print("ItemName change: ");
                    modifys.setString(1, in.nextLine());
                    System.out.print("Input Item ID: ");
                    modifys.setInt(2, in.nextInt());
                    modifys.executeUpdate();
                    con.close();
                }

                if (choosen == 2)
                {
                    String sql = "UPDATE inventory SET ItemType = ? WHERE ItemID = ?";
                    PreparedStatement modifys = con.prepareStatement(sql);
                    con.createStatement();
                    System.out.print("ItemType change: ");
                    modifys.setString(1, in.nextLine());
                    System.out.print("Input Item ID: ");
                    modifys.setInt(2, in.nextInt());
                    modifys.executeUpdate();
                    con.close();
                }

                if (choosen == 3)
                {
                    String sql = "UPDATE inventory SET UnitCost = ? WHERE ItemID = ?";
                    PreparedStatement modifys = con.prepareStatement(sql);
                    con.createStatement();
                    System.out.print("UnitCost change: ");
                    modifys.setInt(1, in.nextInt());
                    System.out.print("Input Item ID: ");
                    modifys.setInt(2, in.nextInt());
                    modifys.executeUpdate();
                    con.close();
                }

                if (choosen == 4)
                {
                    String sql = "UPDATE inventory SET ItemCost = ? WHERE ItemID = ?";
                    PreparedStatement modifys = con.prepareStatement(sql);
                    con.createStatement();
                    System.out.print("ItemCost change: ");
                    modifys.setInt(1, in.nextInt());
                    System.out.print("Input Item ID: ");
                    modifys.setInt(2, in.nextInt());
                    modifys.executeUpdate();
                    con.close();
                }

                if (choosen == 5)
                {
                    String sql = "UPDATE inventory SET ItemQty = ? WHERE ItemID = ?";
                    PreparedStatement modifys = con.prepareStatement(sql);
                    con.createStatement();
                    System.out.print("ItemQty change: ");
                    modifys.setInt(1, in.nextInt());
                    System.out.print("Input Item ID: ");
                    modifys.setInt(2, in.nextInt());
                    modifys.executeUpdate();
                    con.close();
                }
            }
            System.out.println("Item detail is modified in the inventory successfully");
            System.out.println();
        }

        catch(Exception e)
        {
            System.out.println("Error Occured, please try again.");
        }
    }

    /**
     *  This method allows the inventory custodian to
     *  delete the whole row of the Item in the inventory database
     *  when the user inputs the ID of the item, the whole row will be deleted unless
     *  it cannot be deleted to be connected/foreigned key by another table
     *  in the database
     * */
    public void deleteItem()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/breweryinventory","root","josegonzaga" );
            String sql = "delete from inventory where ItemID = ?";
            PreparedStatement delete = con.prepareStatement(sql);
            con.createStatement();
            System.out.print("Input Item ID to delete row: ");
            delete.setInt(1, in.nextInt());
            delete.executeUpdate();
            con.close();
            System.out.println("Item is deleted in the inventory successfully.");
            System.out.println();
        }
        
        catch(Exception e)
        {
            System.out.println("Error Occured, please try again.");
        }
    }
}