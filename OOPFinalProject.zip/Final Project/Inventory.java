public class Inventory
{
    private int itemid;
    private String itemname;
    private String itemtype;
    private int unitcost;
    private int itemcost;
    private int itemquantity;
    
    // Getters for Inventory Class
    public int getItemID()
    {
        return this.itemid;
    }

    public String getItemname()
    {
        return this.itemname;
    }

    public String getItemtype()
    {
        return this.itemtype;
    }

    public int getUnitcost()
    {
        return this.unitcost;
    }

    public int getItemcost()
    {
        return this.itemcost;
    }

    public int getItemquantity()
    {
        return this.itemquantity;
    }

    // Setters for Inventory class
    public int setItemID(int itemid)
    {
        return this.itemid = itemid;
    }

    public String setItemname(String itemname)
    {
        return this.itemname = itemname;
    }

    public String setItemtype(String itemtype)
    {
        return this.itemtype = itemtype;
    }

    public int setUnitcost(int unitcost)
    {
        return this.unitcost = unitcost;
    }

    public int setItemcost(int itemcost)
    {
        return this.itemcost = itemcost;
    }

    public int setItemquantity(int itemquantity)
    {
        return this.itemquantity = itemquantity;
    }
}