/**
 * @author Jose Miguel D. GOnzaga
 * Section: CSCC20 A
 * Date: October 7, 2019
 *
 * FINAL PROJECT : BREWERY INVENTORY DATABASE
 */

import java.util.Scanner;

class Main
{
    public static Order order;
    public static Invsort invs;
    public static Removing rem;
	private static Scanner in;
	
	
	public static void main(String[] args) 
	{
        order = new Order();
        in = new Scanner(System.in);
        rem = new Removing();
        invs = new Invsort(in);
        int choice = 0;

        while(true)
        {
            System.out.println("What position are you?");
			System.out.println("1. Sales Manager");
            System.out.println("2. Inventory Custodian");
            System.out.println("3. Exit Program");
            System.out.print("Choice: ");
            choice = in.nextInt();
            System.out.println();

            switch(choice)
            {
                case 1:
                    System.out.println("Sales Manager options");
                    System.out.println("1. Customer & Sale");
                    System.out.println("2. Supplier & Purchases");
                    System.out.println("3. Delete Customer, Supplier, or Order");
                    System.out.println("4. Back to main menu");
                    System.out.print("Choice: ");
                    int choice2 = in.nextInt();
                    System.out.println();
                    
                    if (choice2 == 1)
                    {
                    	order.setCustomer();
                    	break;
                    }
                    	
                    if (choice2 == 2)
                    {
                    	order.setSupplier();
                    	break;
                    }

                    if (choice2 == 3)
                    {
                        System.out.println("Delete");
                        System.out.println("1. Customer");
                        System.out.println("2. Supplier");
                        System.out.println("3. Order");
                        System.out.print("Choice: ");
                        int chosen = in.nextInt();

                        if (chosen == 1)
                        {
                            rem.delCustomer();
                        }

                        if (chosen == 2)
                        {
                            rem.delSupplier();
                        }

                        if (chosen == 3)
                        {
                            rem.delOrders();
                        }
                    }

                    else if (choice2 == 4)
                    {
                    	break;
                    }
                    break;

                case 2:
                    System.out.println("Inventory Custodian options");
                    System.out.println("1. Add Item");
                    System.out.println("2. Modify Item details");
                    System.out.println("3. Delete Item row");
                    System.out.println("4. Back to main menu");
                    System.out.print("Choice: ");
                    int choice3 = in.nextInt();
                    System.out.println();

                    if (choice3 == 1)
                    {
                        invs.addItem();
                    }

                    if (choice3 == 2)
                    {
                        invs.modifyItem();
                    }

                    if (choice3 == 3)
                    {
                        invs.deleteItem();
                    }

                    else if (choice3 == 4)
                    {
                        break;
                    }
                    break;

                case 3:
                    System.exit(0);
                    break;

                default:
                    System.out.print("Error! There is no option for that");
                    break;
            }
        }
    }
}