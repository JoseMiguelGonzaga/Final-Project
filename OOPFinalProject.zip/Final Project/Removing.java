import java.sql.*;
import java.util.Scanner;

/**
 * The purpose of this class is to remove informations.
 * You can remove customer info, supplier info, and orders
 * in the database through this class
 */
class Removing
{
    private Scanner in;

    // This method deletes customer info in the database
    public void delCustomer()
    {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/breweryinventory","root","josegonzaga" );
            String sql = "delete from customer where CustomerID = ?";
            PreparedStatement delete = con.prepareStatement(sql);
            con.createStatement();
            in = new Scanner(System.in);

            System.out.print("Input customer ID to delete row: ");
            delete.setInt(1, in.nextInt());
            delete.executeUpdate();
            con.close();
            System.out.println("customer is deleted successfully.");
            System.out.println();
        }

        catch(Exception e)
        {
            System.out.println("Error Occured, please try again.");
        }
    }

    // This method deletes supplier info in the database
    public void delSupplier()
    {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/breweryinventory","root","josegonzaga" );
            String sql = "delete from supplier where SupplierID = ?";
            PreparedStatement delete = con.prepareStatement(sql);
            con.createStatement();
            in = new Scanner(System.in);

            System.out.print("Input supplier ID to delete row: ");
            delete.setInt(1, in.nextInt());
            delete.executeUpdate();
            con.close();
            System.out.println("supplier is deleted successfully.");
            System.out.println();
        }

        catch(Exception e)
        {
            System.out.println("Error Occured, please try again.");
        }
    }

    // This method deletes orders in the database
    public void delOrders()
    {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/breweryinventory","root","josegonzaga" );
            String sql = "delete from ordern where OrderNo = ?";
            PreparedStatement delete = con.prepareStatement(sql);
            con.createStatement();
            in = new Scanner(System.in);

            System.out.print("Input Order number to delete row: ");
            delete.setInt(1, in.nextInt());
            delete.executeUpdate();
            con.close();
            System.out.println("order is deleted successfully.");
            System.out.println();
        }

        catch(Exception e)
        {
            System.out.println("Error Occured, please try again.");
        }
    }
}