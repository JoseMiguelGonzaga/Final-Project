
public class OrderLine
{
	private int orderid;
	private String ordername ;
	private int orderquantity;

	//Getters for OrderLine class
	public int getOrderid()
	{
		return this.orderid;
	}

	public String getOrdername()
	{
		return this.ordername;
	}

	public int getOrderquantity()
	{
		return this.orderquantity;
	}

	//Setters for OrderLine class
	public int setOrderid(int orderid)
	{
		return this.orderid = orderid;
	}

	public String setOrdername(String ordername)
	{
		return this.ordername = ordername;
	}

	public int setOrderquantity(int orderquantity)
	{
		return this.orderquantity = orderquantity;
	}
}
