import java.sql.*;
import java.util.Scanner;

/**
 * The purpose of this class is for the sales manager
 * to add customer info and supplier info while taking the orders
 * from the customer / issuing an order to the supplier.
 */
public class Order 
{
	private Scanner in;

	/**
	 * This method adds customer info into the database.
	 * Additionally, the sales manager also adds orders that is being issued by the customer.
	 */
	public void setCustomer() 
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/breweryinventory","root","josegonzaga" );
			PreparedStatement insertone = con.prepareStatement("INSERT INTO ordern(OrderNo,OrderItemName,OrderItemQty) VALUES(?,?,?)");
			PreparedStatement insert = con.prepareStatement("INSERT INTO customer(CustomerID,CustLName,CustContactNo,CustAddress,CustTIN) VALUES(?,?,?,?,?)");
			con.createStatement();
            Customer c = new Customer();
			in = new Scanner(System.in);
			System.out.print("Input number of orders: ");
			int loop = in.nextInt();

			for (int i = 0 ; i < loop ; i++)
			{
				System.out.print("Input Order number: ");
				c.setOrderid(in.nextInt());
				in.nextLine();

				System.out.print("Input Order name: ");
				c.setOrdername(in.nextLine());

				System.out.print("input Order quantity: ");
				c.setOrderquantity(in.nextInt());

				insertone.setInt(1, c.getOrderid());
				insertone.setString(2, c.getOrdername());
				insertone.setInt(3, c.getOrderquantity());
				insertone.executeUpdate();
				System.out.println();
			}
			System.out.println("Order(s) added!");
			System.out.println();

		    System.out.print("Input customer id: ");
			c.setCustomerID(in.nextInt());
			in.nextLine();
		
		    System.out.print("Input customer last name: ");
		    c.setCustomerlname(in.nextLine());
			
		    System.out.print("Input customer address: ");
		    c.setCustomeraddress(in.nextLine());
		
		    System.out.print("Input customer contact number: ");
			c.setCustomercontactno(in.nextLine());

			System.out.print("Input customer TIN: ");
			c.setCustomertin(in.nextInt());

			insert.setInt(1,c.getCustomerID());
            insert.setString(2,c.getCustomerlname());
            insert.setString(3,c.getCustomeraddress());
            insert.setString(4,c.getCustomercontactno());
			insert.setInt(5,c.getCustomertin());
			insert.executeUpdate();
            con.close();
			System.out.println("Customer added!");
			System.out.println();
		}
		
		catch(Exception e)
        {
            System.out.println("Error Occured, please try again.");
        }
	}
	
	/**
	 * This method adds supplier info into the database.
	 * Additionally, sales manager can also input the orders(purchases)
	 * that is issued by the sales manager in order to get products
	 * from the supplier.
	 */
	public void setSupplier()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/breweryinventory","root","josegonzaga" );
			PreparedStatement insertone = con.prepareStatement("INSERT INTO ordern(OrderNo,OrderItemName,OrderItemQty) VALUES(?,?,?)");
			PreparedStatement inserttwo = con.prepareStatement("INSERT INTO supplier(SupplierID,SupplierName,SupplierAddress,SupplierContactNo) VALUES(?,?,?,?)");
			con.createStatement();
            Supplier s = new Supplier();
			in = new Scanner(System.in);
			System.out.print("Input number of orders: ");
			int loop = in.nextInt();

			for (int i = 0 ; i < loop ; i++)
			{
				System.out.print("Input Order number: ");
				s.setOrderid(in.nextInt());
				in.nextLine();

				System.out.print("Input Order name: ");
				s.setOrdername(in.nextLine());

				System.out.print("input Order quantity: ");
				s.setOrderquantity(in.nextInt());

				insertone.setInt(1, s.getOrderid());
				insertone.setString(2, s.getOrdername());
				insertone.setInt(3, s.getOrderquantity());
				insertone.executeUpdate();
				System.out.println();
			}
			System.out.println("Order(s) added!");
			System.out.println();

		    System.out.print("Enter supplier ID: ");
			s.setSupplierID(in.nextInt());
			in.nextLine();
		
		    System.out.print("Enter Supplier name: ");
		    s.setSuppliername(in.nextLine());
		
		    System.out.print("Enter supplier address: ");
		    s.setSupplieraddress(in.nextLine());
		
		    System.out.print("Enter supplier contact number: ");
			s.setSuppliercontactno(in.nextLine());
			
			inserttwo.setInt(1,s.getSupplierID());
            inserttwo.setString(2,s.getSuppliername());
            inserttwo.setString(3,s.getSupplieraddress());
            inserttwo.setString(4,s.getSuppliercontactno());
			inserttwo.executeUpdate();
            con.close();
			System.out.println("Purchase and Supplier is added!");
			System.out.println();
		}
		
		catch(Exception e)
        {
            System.out.println("Error Occured, please try again.");
        }
	}
}
