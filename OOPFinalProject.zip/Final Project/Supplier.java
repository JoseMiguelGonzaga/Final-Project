
public class Supplier extends OrderLine
{
	private int supplierid;
	private String suppliername;
	private String supplieraddress;
	private String suppliercontactno;

	// Getters for Supplier class
	public int getSupplierID()
	{
		return this.supplierid;
	}
	
	public String getSuppliername()
	{
		return this.suppliername;
	}
	
	public String getSupplieraddress()
	{
		return this.supplieraddress;
	}
	
	public String getSuppliercontactno()
	{
		return this.suppliercontactno;
	}
	
	// Setters for Supplier class
	public int setSupplierID(int supplierid)
	{
		return this.supplierid = supplierid;
	}
	
	public String setSuppliername(String suppliername)
	{
		return this.suppliername = suppliername;
	}
	
	public String setSupplieraddress(String supplieraddress)
	{
		return this.supplieraddress = supplieraddress;
	}
	
	public String setSuppliercontactno(String suppliercontactno)
	{
		return this.suppliercontactno = suppliercontactno;
	}
}
